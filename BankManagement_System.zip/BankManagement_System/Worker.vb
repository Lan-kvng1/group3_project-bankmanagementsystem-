﻿Imports System.Data.SqlClient

Public Class Worker
    Dim con As New SqlConnection("Data Source=SECRET-GUEST;Initial Catalog=BankDB;Integrated Security=True")
    Dim cmd As SqlCommand
    Dim adapter As SqlDataAdapter
    Dim dt As DataTable

    ' Clear input fields
    Private Sub ClearFields()
        txtWID.Text = ""
        txtName.Text = ""
        txtPosition.Text = ""
        txtSalary.Text = ""
    End Sub

    ' Load data into DataGridView
    Private Sub LoadWorkers()
        Try
            If con.State = ConnectionState.Open Then con.Close()
            con.Open()
            Dim query As String = "SELECT * FROM workers"
            adapter = New SqlDataAdapter(query, con)
            dt = New DataTable()
            adapter.Fill(dt)
            dgvWorkers.DataSource = dt
        Catch ex As Exception
            MessageBox.Show("Error loading workers: " & ex.Message)
        Finally
            If con.State = ConnectionState.Open Then con.Close()
        End Try
    End Sub

    ' Save worker to database
    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        Try
            If txtWID.Text = "" Or txtName.Text = "" Or txtPosition.Text = "" Or txtSalary.Text = "" Then
                MessageBox.Show("Please fill all fields.")
                Return
            End If

            If con.State = ConnectionState.Open Then con.Close()
            con.Open()
            Dim query As String = "INSERT INTO workers (WID, Name, Position, Salary) VALUES (@WID, @Name, @Position, @Salary)"
            cmd = New SqlCommand(query, con)
            cmd.Parameters.AddWithValue("@WID", txtWID.Text)
            cmd.Parameters.AddWithValue("@Name", txtName.Text)
            cmd.Parameters.AddWithValue("@Position", txtPosition.Text)
            cmd.Parameters.AddWithValue("@Salary", txtSalary.Text)
            cmd.ExecuteNonQuery()

            MessageBox.Show("Worker saved successfully.")
        Catch ex As Exception
            MessageBox.Show("Error saving worker: " & ex.Message)
        Finally
            If con.State = ConnectionState.Open Then con.Close()
            LoadWorkers()
            ClearFields()
        End Try
    End Sub

    ' Add - just clears fields for new entry
    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        ClearFields()
    End Sub

    ' Update worker
    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        Try
            If txtWID.Text = "" Then
                MessageBox.Show("Please select a worker to update.")
                Return
            End If

            If con.State = ConnectionState.Open Then con.Close()
            con.Open()
            Dim query As String = "UPDATE workers SET Name=@Name, Position=@Position, Salary=@Salary WHERE WID=@WID"
            cmd = New SqlCommand(query, con)
            cmd.Parameters.AddWithValue("@WID", txtWID.Text)
            cmd.Parameters.AddWithValue("@Name", txtName.Text)
            cmd.Parameters.AddWithValue("@Position", txtPosition.Text)
            cmd.Parameters.AddWithValue("@Salary", txtSalary.Text)
            cmd.ExecuteNonQuery()

            MessageBox.Show("Worker updated successfully.")
        Catch ex As Exception
            MessageBox.Show("Error updating worker: " & ex.Message)
        Finally
            If con.State = ConnectionState.Open Then con.Close()
            LoadWorkers()
            ClearFields()
        End Try
    End Sub

    ' Delete worker
    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        Try
            If txtWID.Text = "" Then
                MessageBox.Show("Please select a worker to delete.")
                Return
            End If

            If con.State = ConnectionState.Open Then con.Close()
            con.Open()
            Dim query As String = "DELETE FROM workers WHERE WID=@WID"
            cmd = New SqlCommand(query, con)
            cmd.Parameters.AddWithValue("@WID", txtWID.Text)
            cmd.ExecuteNonQuery()

            MessageBox.Show("Worker deleted successfully.")
        Catch ex As Exception
            MessageBox.Show("Error deleting worker: " & ex.Message)
        Finally
            If con.State = ConnectionState.Open Then con.Close()
            LoadWorkers()
            ClearFields()
        End Try
    End Sub

    ' Load selected row to fields
    Private Sub DataGridView1_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgvWorkers.CellClick
        If e.RowIndex >= 0 Then
            Dim row As DataGridViewRow = dgvWorkers.Rows(e.RowIndex)
            txtWID.Text = row.Cells("WID").Value.ToString()
            txtName.Text = row.Cells("Name").Value.ToString()
            txtPosition.Text = row.Cells("Position").Value.ToString()
            txtSalary.Text = row.Cells("Salary").Value.ToString()
        End If
    End Sub

    ' Form load event
    Private Sub Worker_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        LoadWorkers()
    End Sub
End Class
