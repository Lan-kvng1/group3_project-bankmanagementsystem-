﻿Imports System.Data.SqlClient

Public Class Form1
    ' Connection string - adjust server name if needed
    Private connectionString As String = "Data Source=SECRET-GUEST;Initial Catalog=bankDB;Integrated Security=True"

    Private Sub LoginButton_Click(sender As Object, e As EventArgs) Handles btnLogin.Click
        Dim username As String = txtUsername.Text.Trim()
        Dim password As String = txtPassword.Text.Trim()

        ' Validate inputs
        If String.IsNullOrEmpty(username) OrElse String.IsNullOrEmpty(password) Then
            MessageBox.Show("Please enter both username and password", "Login Failed", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return
        End If

        ' Check credentials against database
        If ValidateLogin(username, password) Then
            MessageBox.Show("Login successful!", "Welcome", MessageBoxButtons.OK, MessageBoxIcon.Information)
            ' TODO: Navigate to main form or dashboard
            Main.Show() ' Replace 'Main' with your actual main form class name
            Me.Hide()
        Else
            MessageBox.Show("Invalid username or password", "Login Failed", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If
    End Sub

    Private Function ValidateLogin(username As String, password As String) As Boolean
        Dim isValid As Boolean = False

        Using connection As New SqlConnection(connectionString)
            Try
                connection.Open()

                ' Use parameterized query to prevent SQL injection
                Dim query As String = "SELECT COUNT(*) FROM logintab WHERE username COLLATE SQL_Latin1_General_CP1_CS_AS = @Username AND password COLLATE SQL_Latin1_General_CP1_CS_AS = @Password"
                Using command As New SqlCommand(query, connection)
                    command.Parameters.AddWithValue("@Username", username)
                    command.Parameters.AddWithValue("@Password", password)

                    Dim count As Integer = CInt(command.ExecuteScalar())
                    isValid = (count > 0)
                End Using

            Catch ex As Exception
                MessageBox.Show("Database error: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        End Using

        Return isValid
    End Function

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Application.Exit()
    End Sub

    Private Sub CheckBox1_CheckedChanged(sender As Object, e As EventArgs) Handles cbShow.CheckedChanged
        If cbShow.Checked Then
            txtPassword.UseSystemPasswordChar = False ' Show the password
        Else
            txtPassword.UseSystemPasswordChar = True ' Mask the password
        End If
    End Sub

    Private Sub btnForgotPassword_Click(sender As Object, e As EventArgs) Handles btnForgotPassword.Click
        Dim username As String = txtUsername.Text.Trim()

        ' Check if the username field is empty
        If String.IsNullOrEmpty(username) Then
            MessageBox.Show("Please enter your username to reset the password.", "Forgot Password", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return
        End If

        Using connection As New SqlConnection(connectionString)
            Try
                connection.Open()

                ' Query to check if the username exists
                Dim query As String = "SELECT password FROM logintab WHERE username COLLATE SQL_Latin1_General_CP1_CS_AS = @Username"
                Using command As New SqlCommand(query, connection)
                    command.Parameters.AddWithValue("@Username", username)

                    Dim result As Object = command.ExecuteScalar()
                    If result IsNot Nothing Then
                        Dim password As String = result.ToString()
                        MessageBox.Show($"Your password is: {password}", "Forgot Password", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    Else
                        MessageBox.Show("Username not found. Please check your input.", "Forgot Password", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    End If
                End Using

            Catch ex As Exception
                MessageBox.Show("Database error: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        End Using
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Ensure the password is masked by default
        txtPassword.UseSystemPasswordChar = True
    End Sub
End Class
