﻿Imports System.Data.SqlClient

Public Class Dashboard
    Dim con As New SqlConnection("Data Source=SECRET-GUEST;Initial Catalog=BankDB;Integrated Security=True")

    Private Sub Dashboard_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        LoadDashboardCounts()
        dbtDashboard.Interval = 5000 ' Refresh every 5 seconds
        dbtDashboard.Start()
    End Sub

    Private Sub LoadDashboardCounts()
        Try
            If con.State = ConnectionState.Open Then con.Close()
            con.Open()

            ' Total Customers
            Using cmd1 As New SqlCommand("SELECT COUNT(*) FROM customers", con)
                lblCount1.Text = cmd1.ExecuteScalar().ToString()
            End Using

            ' Total Loans
            Using cmd2 As New SqlCommand("SELECT COUNT(*) FROM loans", con)
                lblCount2.Text = cmd2.ExecuteScalar().ToString()
            End Using

            ' Total Workers
            Using cmd3 As New SqlCommand("SELECT COUNT(*) FROM workers", con)
                lblCount3.Text = cmd3.ExecuteScalar().ToString()
            End Using

        Catch ex As Exception
            MessageBox.Show("Error loading dashboard data: " & ex.Message)
        Finally
            If con.State = ConnectionState.Open Then con.Close()
        End Try
    End Sub

    Private Sub dbtDashboard_Tick(sender As Object, e As EventArgs) Handles dbtDashboard.Tick
        LoadDashboardCounts()
    End Sub
End Class
