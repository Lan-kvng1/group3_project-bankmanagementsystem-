﻿Imports System.Data.SqlClient

Public Class Loan
    Dim con As New SqlConnection("Data Source=SECRET-GUEST;Initial Catalog=BankDB;Integrated Security=True")
    Dim cmd As SqlCommand
    Dim da As SqlDataAdapter
    Dim dt As DataTable

    Private Sub LoadLoans()
        Try
            con.Open()
            da = New SqlDataAdapter("SELECT * FROM loans", con)
            dt = New DataTable()
            da.Fill(dt)
            dgvLoan.DataSource = dt
            con.Close()
        Catch ex As Exception
            MessageBox.Show("Error loading data: " & ex.Message)
            con.Close()
        End Try
    End Sub

    Private Sub ClearFields()
        txtLoanID.Clear()
        txtLoanType.Clear()
        txtAmount.Clear()
        txtInterestRate.Clear()
        dtpLoanDate.Value = DateTime.Now
        txtCustomerName.Clear()
    End Sub

    Private Sub Loan_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        LoadLoans()
    End Sub

    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        ClearFields()
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        Try
            con.Open()
            cmd = New SqlCommand("INSERT INTO loans (Loan_ID, Loan_Type, Amount, Interest_Rate, Loan_Date, Customer_Name) 
                                  VALUES (@Loan_ID, @Loan_Type, @Amount, @Interest_Rate, @Loan_Date, @Customer_Name)", con)
            cmd.Parameters.AddWithValue("@Loan_ID", txtLoanID.Text)
            cmd.Parameters.AddWithValue("@Loan_Type", txtLoanType.Text)
            cmd.Parameters.AddWithValue("@Amount", txtAmount.Text)
            cmd.Parameters.AddWithValue("@Interest_Rate", txtInterestRate.Text)
            cmd.Parameters.AddWithValue("@Loan_Date", dtpLoanDate.Value)
            cmd.Parameters.AddWithValue("@Customer_Name", txtCustomerName.Text)
            cmd.ExecuteNonQuery()
            con.Close()
            MessageBox.Show("Loan Saved Successfully!")
            LoadLoans()
            ClearFields()
        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message)
            con.Close()
        End Try
    End Sub

    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        Try
            con.Open()
            cmd = New SqlCommand("UPDATE loans SET Loan_Type=@Loan_Type, Amount=@Amount, Interest_Rate=@Interest_Rate, 
                                  Loan_Date=@Loan_Date, Customer_Name=@Customer_Name WHERE Loan_ID=@Loan_ID", con)
            cmd.Parameters.AddWithValue("@Loan_ID", txtLoanID.Text)
            cmd.Parameters.AddWithValue("@Loan_Type", txtLoanType.Text)
            cmd.Parameters.AddWithValue("@Amount", txtAmount.Text)
            cmd.Parameters.AddWithValue("@Interest_Rate", txtInterestRate.Text)
            cmd.Parameters.AddWithValue("@Loan_Date", dtpLoanDate.Value)
            cmd.Parameters.AddWithValue("@Customer_Name", txtCustomerName.Text)
            cmd.ExecuteNonQuery()
            con.Close()
            MessageBox.Show("Loan Updated Successfully!")
            LoadLoans()
            ClearFields()
        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message)
            con.Close()
        End Try
    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        Try
            con.Open()
            cmd = New SqlCommand("DELETE FROM loans WHERE Loan_ID=@Loan_ID", con)
            cmd.Parameters.AddWithValue("@Loan_ID", txtLoanID.Text)
            cmd.ExecuteNonQuery()
            con.Close()
            MessageBox.Show("Loan Deleted Successfully!")
            LoadLoans()
            ClearFields()
        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message)
            con.Close()
        End Try
    End Sub

    Private Sub DataGridView1_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgvLoan.CellClick
        If e.RowIndex >= 0 Then
            Dim row As DataGridViewRow = dgvLoan.Rows(e.RowIndex)
            txtLoanID.Text = row.Cells("Loan_ID").Value.ToString()
            txtLoanType.Text = row.Cells("Loan_Type").Value.ToString()
            txtAmount.Text = row.Cells("Amount").Value.ToString()
            txtInterestRate.Text = row.Cells("Interest_Rate").Value.ToString()
            dtpLoanDate.Value = Convert.ToDateTime(row.Cells("Loan_Date").Value)
            txtCustomerName.Text = row.Cells("Customer_Name").Value.ToString()
        End If
    End Sub
End Class
