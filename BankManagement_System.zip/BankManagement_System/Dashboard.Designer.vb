﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Dashboard
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.lblEverydayBank = New System.Windows.Forms.Label()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.lblCount1 = New System.Windows.Forms.Label()
        Me.lblTotalCustomers = New System.Windows.Forms.Label()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.lblCount2 = New System.Windows.Forms.Label()
        Me.lblTotalLoans = New System.Windows.Forms.Label()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.lblCount3 = New System.Windows.Forms.Label()
        Me.lblTotalWorkers = New System.Windows.Forms.Label()
        Me.dbtDashboard = New System.Windows.Forms.Timer(Me.components)
        Me.Panel1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.Panel4.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.DimGray
        Me.Panel1.Controls.Add(Me.lblEverydayBank)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1137, 114)
        Me.Panel1.TabIndex = 0
        '
        'lblEverydayBank
        '
        Me.lblEverydayBank.AutoSize = True
        Me.lblEverydayBank.Font = New System.Drawing.Font("Arial", 20.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblEverydayBank.ForeColor = System.Drawing.Color.White
        Me.lblEverydayBank.Location = New System.Drawing.Point(410, 29)
        Me.lblEverydayBank.Name = "lblEverydayBank"
        Me.lblEverydayBank.Size = New System.Drawing.Size(277, 46)
        Me.lblEverydayBank.TabIndex = 1
        Me.lblEverydayBank.Text = "DASHBOARD"
        '
        'Panel2
        '
        Me.Panel2.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Panel2.BackColor = System.Drawing.Color.Chocolate
        Me.Panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel2.Controls.Add(Me.lblCount1)
        Me.Panel2.Controls.Add(Me.lblTotalCustomers)
        Me.Panel2.Location = New System.Drawing.Point(129, 161)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(225, 225)
        Me.Panel2.TabIndex = 1
        '
        'lblCount1
        '
        Me.lblCount1.AutoSize = True
        Me.lblCount1.Font = New System.Drawing.Font("Arial", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCount1.ForeColor = System.Drawing.Color.White
        Me.lblCount1.Location = New System.Drawing.Point(83, 91)
        Me.lblCount1.Name = "lblCount1"
        Me.lblCount1.Size = New System.Drawing.Size(51, 56)
        Me.lblCount1.TabIndex = 5
        Me.lblCount1.Text = "0"
        '
        'lblTotalCustomers
        '
        Me.lblTotalCustomers.AutoSize = True
        Me.lblTotalCustomers.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTotalCustomers.ForeColor = System.Drawing.Color.White
        Me.lblTotalCustomers.Location = New System.Drawing.Point(8, 37)
        Me.lblTotalCustomers.Name = "lblTotalCustomers"
        Me.lblTotalCustomers.Size = New System.Drawing.Size(207, 29)
        Me.lblTotalCustomers.TabIndex = 4
        Me.lblTotalCustomers.Text = "Total Customers:"
        '
        'Panel3
        '
        Me.Panel3.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Panel3.BackColor = System.Drawing.Color.Chocolate
        Me.Panel3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel3.Controls.Add(Me.lblCount2)
        Me.Panel3.Controls.Add(Me.lblTotalLoans)
        Me.Panel3.Location = New System.Drawing.Point(765, 161)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(225, 225)
        Me.Panel3.TabIndex = 2
        '
        'lblCount2
        '
        Me.lblCount2.AutoSize = True
        Me.lblCount2.Font = New System.Drawing.Font("Arial", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCount2.ForeColor = System.Drawing.Color.White
        Me.lblCount2.Location = New System.Drawing.Point(84, 91)
        Me.lblCount2.Name = "lblCount2"
        Me.lblCount2.Size = New System.Drawing.Size(51, 56)
        Me.lblCount2.TabIndex = 7
        Me.lblCount2.Text = "0"
        '
        'lblTotalLoans
        '
        Me.lblTotalLoans.AutoSize = True
        Me.lblTotalLoans.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTotalLoans.ForeColor = System.Drawing.Color.White
        Me.lblTotalLoans.Location = New System.Drawing.Point(32, 37)
        Me.lblTotalLoans.Name = "lblTotalLoans"
        Me.lblTotalLoans.Size = New System.Drawing.Size(154, 29)
        Me.lblTotalLoans.TabIndex = 6
        Me.lblTotalLoans.Text = "Total Loans:"
        '
        'Panel4
        '
        Me.Panel4.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Panel4.BackColor = System.Drawing.Color.Chocolate
        Me.Panel4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel4.Controls.Add(Me.lblCount3)
        Me.Panel4.Controls.Add(Me.lblTotalWorkers)
        Me.Panel4.Location = New System.Drawing.Point(439, 417)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(225, 225)
        Me.Panel4.TabIndex = 3
        '
        'lblCount3
        '
        Me.lblCount3.AutoSize = True
        Me.lblCount3.Font = New System.Drawing.Font("Arial", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCount3.ForeColor = System.Drawing.Color.White
        Me.lblCount3.Location = New System.Drawing.Point(81, 100)
        Me.lblCount3.Name = "lblCount3"
        Me.lblCount3.Size = New System.Drawing.Size(51, 56)
        Me.lblCount3.TabIndex = 9
        Me.lblCount3.Text = "0"
        '
        'lblTotalWorkers
        '
        Me.lblTotalWorkers.AutoSize = True
        Me.lblTotalWorkers.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTotalWorkers.ForeColor = System.Drawing.Color.White
        Me.lblTotalWorkers.Location = New System.Drawing.Point(16, 45)
        Me.lblTotalWorkers.Name = "lblTotalWorkers"
        Me.lblTotalWorkers.Size = New System.Drawing.Size(178, 29)
        Me.lblTotalWorkers.TabIndex = 8
        Me.lblTotalWorkers.Text = "Total Workers:"
        '
        'dbtDashboard
        '
        Me.dbtDashboard.Enabled = True
        Me.dbtDashboard.Interval = 5000
        '
        'Dashboard
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.BankManagement_System.My.Resources.Resources.bank
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(1137, 668)
        Me.Controls.Add(Me.Panel4)
        Me.Controls.Add(Me.Panel3)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel1)
        Me.Name = "Dashboard"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Dashboard"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        Me.Panel4.ResumeLayout(False)
        Me.Panel4.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents lblEverydayBank As Label
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Panel3 As Panel
    Friend WithEvents Panel4 As Panel
    Friend WithEvents lblTotalCustomers As Label
    Friend WithEvents lblCount1 As Label
    Friend WithEvents lblCount2 As Label
    Friend WithEvents lblTotalLoans As Label
    Friend WithEvents lblCount3 As Label
    Friend WithEvents lblTotalWorkers As Label
    Friend WithEvents dbtDashboard As Timer
End Class
