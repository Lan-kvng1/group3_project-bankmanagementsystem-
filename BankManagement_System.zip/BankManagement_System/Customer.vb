﻿Imports System.Data.SqlClient

Public Class Customer
    ' Connection string - modify with your actual database connection
    Private connectionString As String = "Data Source=SECRET-GUEST;Initial Catalog=bankDB;Integrated Security=True"
    Private isNewCustomer As Boolean = True

    ' Form load event
    Private Sub Customer_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ClearFields()
        LoadCustomerData()
    End Sub

    ' Save button click event
    Private Sub Save_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        If ValidateFields() Then
            If isNewCustomer Then
                SaveNewCustomer()
            Else
                UpdateCustomer()
            End If
            LoadCustomerData() ' Refresh the grid
        End If
    End Sub

    ' Add button click event
    Private Sub Add_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        ClearFields()
        isNewCustomer = True
    End Sub

    ' Update button click event
    Private Sub Update_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        If Not String.IsNullOrEmpty(txtCustomerID.Text) Then
            LoadCustomerDetails(txtCustomerID.Text.Trim())
            isNewCustomer = False
        Else
            MessageBox.Show("Please enter a Customer ID to update", "Missing Information", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        End If
    End Sub

    ' Delete button click event
    Private Sub Delete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        If Not String.IsNullOrEmpty(txtCustomerID.Text) Then
            DeleteCustomer(txtCustomerID.Text.Trim())
        Else
            MessageBox.Show("Please enter a Customer ID to delete", "Missing Information", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        End If
    End Sub

    ' Helper method to validate form fields
    Private Function ValidateFields() As Boolean
        If String.IsNullOrEmpty(txtCustomerName.Text) Then
            MessageBox.Show("Customer Name is required", "Missing Information", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtCustomerName.Focus()
            Return False
        End If

        If String.IsNullOrEmpty(txtPhone.Text) Then
            MessageBox.Show("Phone number is required", "Missing Information", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtPhone.Focus()
            Return False
        End If

        If String.IsNullOrEmpty(txtEmail.Text) Then
            MessageBox.Show("Email is required", "Missing Information", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtEmail.Focus()
            Return False
        End If

        Return True
    End Function

    ' Helper method to save a new customer
    Private Sub SaveNewCustomer()
        Using connection As New SqlConnection(connectionString)
            Try
                connection.Open()

                ' First, check if there's auto-increment on the ID field
                Dim identityQuery As String = "SELECT OBJECTPROPERTY(OBJECT_ID('customers'), 'TableHasIdentity')"
                Dim hasIdentity As Boolean = False

                Using cmdCheck As New SqlCommand(identityQuery, connection)
                    Try
                        hasIdentity = Convert.ToBoolean(cmdCheck.ExecuteScalar())
                    Catch
                        ' If the query fails, assume no identity
                        hasIdentity = False
                    End Try
                End Using

                Dim query As String

                If hasIdentity Then
                    ' If identity column exists, let SQL Server generate the ID
                    query = "INSERT INTO customers (Customer_Name, Phone, Email, Address) OUTPUT INSERTED.customer_ID VALUES (@Name, @Phone, @Email, @Address)"

                    Using command As New SqlCommand(query, connection)
                        command.Parameters.AddWithValue("@Name", txtCustomerName.Text.Trim())
                        command.Parameters.AddWithValue("@Phone", txtPhone.Text.Trim())
                        command.Parameters.AddWithValue("@Email", txtEmail.Text.Trim())
                        command.Parameters.AddWithValue("@Address", If(String.IsNullOrEmpty(txtAddress.Text), DBNull.Value, txtAddress.Text.Trim()))

                        Dim newId = command.ExecuteScalar()
                        txtCustomerID.Text = newId.ToString()

                        MessageBox.Show("Customer saved successfully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    End Using
                Else
                    ' If no identity column, ensure Customer_ID is explicitly provided
                    If String.IsNullOrEmpty(txtCustomerID.Text) Then
                        MessageBox.Show("Customer ID is required", "Missing Information", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                        txtCustomerID.Focus()
                        Return
                    End If

                    query = "INSERT INTO customers (customer_ID, Customer_Name, Phone, Email, Address) VALUES (@ID, @Name, @Phone, @Email, @Address)"

                    Using command As New SqlCommand(query, connection)
                        command.Parameters.AddWithValue("@ID", txtCustomerID.Text.Trim())
                        command.Parameters.AddWithValue("@Name", txtCustomerName.Text.Trim())
                        command.Parameters.AddWithValue("@Phone", txtPhone.Text.Trim())
                        command.Parameters.AddWithValue("@Email", txtEmail.Text.Trim())
                        command.Parameters.AddWithValue("@Address", If(String.IsNullOrEmpty(txtAddress.Text), DBNull.Value, txtAddress.Text.Trim()))

                        command.ExecuteNonQuery()
                        MessageBox.Show("Customer saved successfully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    End Using
                End If

                isNewCustomer = False

            Catch ex As Exception
                MessageBox.Show("Error saving customer: " & ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        End Using
    End Sub

    ' Helper method to update an existing customer
    Private Sub UpdateCustomer()
        Using connection As New SqlConnection(connectionString)
            Try
                connection.Open()

                Dim query As String = "UPDATE customer SET Customer_Name = @Name, Phone = @Phone, Email = @Email, Address = @Address WHERE customer_ID = @ID"

                Using command As New SqlCommand(query, connection)
                    command.Parameters.AddWithValue("@ID", txtCustomerID.Text.Trim())
                    command.Parameters.AddWithValue("@Name", txtCustomerName.Text.Trim())
                    command.Parameters.AddWithValue("@Phone", txtPhone.Text.Trim())
                    command.Parameters.AddWithValue("@Email", txtEmail.Text.Trim())
                    command.Parameters.AddWithValue("@Address", If(String.IsNullOrEmpty(txtAddress.Text), DBNull.Value, txtAddress.Text.Trim()))

                    Dim rowsAffected = command.ExecuteNonQuery()

                    If rowsAffected > 0 Then
                        MessageBox.Show("Customer updated successfully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    Else
                        MessageBox.Show("No customer found with ID: " & txtCustomerID.Text, "Not Found", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                    End If
                End Using

            Catch ex As Exception
                MessageBox.Show("Error updating customer: " & ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        End Using
    End Sub

    ' Helper method to load customer details for updating
    Private Sub LoadCustomerDetails(customerID As String)
        Using connection As New SqlConnection(connectionString)
            Try
                connection.Open()

                Dim query As String = "SELECT * FROM customers WHERE customer_ID = @ID"

                Using command As New SqlCommand(query, connection)
                    command.Parameters.AddWithValue("@ID", customerID)

                    Using reader As SqlDataReader = command.ExecuteReader()
                        If reader.Read() Then
                            txtCustomerName.Text = reader("Customer_Name").ToString()
                            txtPhone.Text = reader("Phone").ToString()
                            txtEmail.Text = reader("Email").ToString()
                            txtAddress.Text = If(reader.IsDBNull(reader.GetOrdinal("Address")), String.Empty, reader("Address").ToString())
                        Else
                            MessageBox.Show("No customer found with ID: " & customerID, "Not Found", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                            ClearFields()
                        End If
                    End Using
                End Using

            Catch ex As Exception
                MessageBox.Show("Error loading customer details: " & ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        End Using
    End Sub

    ' Helper method to delete a customer
    Private Sub DeleteCustomer(customerID As String)
        ' Confirm deletion
        Dim result = MessageBox.Show("Are you sure you want to delete customer with ID: " & customerID & "?", "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Question)

        If result = DialogResult.Yes Then
            Using connection As New SqlConnection(connectionString)
                Try
                    connection.Open()

                    Dim query As String = "DELETE FROM customers WHERE customer_ID = @ID"

                    Using command As New SqlCommand(query, connection)
                        command.Parameters.AddWithValue("@ID", customerID)

                        Dim rowsAffected = command.ExecuteNonQuery()

                        If rowsAffected > 0 Then
                            MessageBox.Show("Customer deleted successfully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
                            ClearFields()
                            LoadCustomerData() ' Refresh the grid
                        Else
                            MessageBox.Show("No customer found with ID: " & customerID, "Not Found", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                        End If
                    End Using

                Catch ex As Exception
                    MessageBox.Show("Error deleting customer: " & ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                End Try
            End Using
        End If
    End Sub

    ' Helper method to clear all form fields
    Private Sub ClearFields()
        txtCustomerID.Text = String.Empty
        txtCustomerName.Text = String.Empty
        txtPhone.Text = String.Empty
        txtEmail.Text = String.Empty
        txtAddress.Text = String.Empty
        isNewCustomer = True
    End Sub

    ' Method to load customer data into the DataGridView
    Private Sub LoadCustomerData()
        Using connection As New SqlConnection(connectionString)
            Try
                connection.Open()
                Dim query As String = "SELECT customer_ID, Customer_Name, Phone, Email, Address FROM customers"
                Dim adapter As New SqlDataAdapter(query, connection)
                Dim table As New DataTable()
                adapter.Fill(table)

                ' Assuming you have a DataGridView named dgv in your form
                dgv.DataSource = table

                ' Format the data grid
                dgv.Columns("customer_ID").HeaderText = "Customer ID"
                dgv.Columns("Customer_Name").HeaderText = "Customer Name"
                dgv.Columns("Phone").HeaderText = "Phone"
                dgv.Columns("Email").HeaderText = "Email"
                dgv.Columns("Address").HeaderText = "Address"

                dgv.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill

            Catch ex As Exception
                MessageBox.Show("Error loading customer data: " & ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        End Using
    End Sub

    ' Event handler for clicking on a row in the DataGridView
    Private Sub dgv_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgv.CellClick
        If e.RowIndex >= 0 Then
            Dim selectedRow As DataGridViewRow = dgv.Rows(e.RowIndex)

            txtCustomerID.Text = selectedRow.Cells("customer_ID").Value.ToString()
            txtCustomerName.Text = selectedRow.Cells("Customer_Name").Value.ToString()
            txtPhone.Text = selectedRow.Cells("Phone").Value.ToString()
            txtEmail.Text = selectedRow.Cells("Email").Value.ToString()
            txtAddress.Text = If(selectedRow.Cells("Address").Value Is DBNull.Value, String.Empty, selectedRow.Cells("Address").Value.ToString())

            isNewCustomer = False
        End If
    End Sub

End Class
