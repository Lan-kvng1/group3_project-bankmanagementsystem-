﻿Public Class Main

    Private Sub btnCustomer_Click(sender As Object, e As EventArgs) Handles btnCustomer.Click
        Dim form2 As New Main()
        Customer.Show()
    End Sub

    Private Sub btnAccount_Click(sender As Object, e As EventArgs) Handles btnAccount.Click
        Dim form2 As New Main()
        Account.Show()
    End Sub

    Private Sub btnTransaction_Click(sender As Object, e As EventArgs) Handles btnTransaction.Click
        Dim forms As New Main()
        Transaction.Show()
    End Sub

    Private Sub btnLoan_Click(sender As Object, e As EventArgs) Handles btnLoan.Click
        Dim forms As New Main()
        Loan.Show()
    End Sub

    Private Sub btnDashboard_Click(sender As Object, e As EventArgs) Handles btnDashboard.Click
        Dim forms As New Main()
        Dashboard.Show()
    End Sub

    Private Sub btnWorker_Click(sender As Object, e As EventArgs) Handles btnWorker.Click
        Dim focus As New Main()
        Worker.Show()
    End Sub

    Private Sub btnLogin_Click(sender As Object, e As EventArgs) Handles btnLogin.Click
        Dim forms As New Main()
        Form1.Show()
        Me.Hide()
    End Sub
End Class