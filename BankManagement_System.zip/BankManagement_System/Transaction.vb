﻿' Import necessary namespaces
Imports System.Data.SqlClient

Public Class Transaction
    ' Define SQL Server connection
    Dim con As New SqlConnection("Data Source=SECRET-GUEST;Initial Catalog=BankDB;Integrated Security=True")

    ' Load transactions when form loads
    Private Sub Transaction_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        LoadTransactions()
    End Sub

    ' Load transaction data from database
    Private Sub LoadTransactions()
        Try
            Dim cmd As New SqlCommand("SELECT * FROM [transaction]", con)
            Dim adapter As New SqlDataAdapter(cmd)
            Dim table As New DataTable()
            adapter.Fill(table)
            dgvTransaction.DataSource = table
        Catch ex As Exception
            MessageBox.Show("Error loading data: " & ex.Message)
        End Try
    End Sub

    ' Add new transaction
    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        Try
            Dim cmd As New SqlCommand("INSERT INTO [transaction] (TID, Transaction_Type, Amount, Transaction_Date, Account_Id) VALUES (@tid, @type, @amt, @date, @accid)", con)
            cmd.Parameters.AddWithValue("@tid", txtTID.Text)
            cmd.Parameters.AddWithValue("@type", txtTransactionType.Text)
            cmd.Parameters.AddWithValue("@amt", txtAmount.Text)
            cmd.Parameters.AddWithValue("@date", dtpTransactionDate.Value)
            cmd.Parameters.AddWithValue("@accid", txtAccountId.Text)

            con.Open()
            cmd.ExecuteNonQuery()
            con.Close()

            MessageBox.Show("Transaction added successfully!")
            LoadTransactions()
        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message)
        Finally
            con.Close()
        End Try
    End Sub

    ' Update transaction
    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        Try
            Dim cmd As New SqlCommand("UPDATE [transaction] SET Transaction_Type=@type, Amount=@amt, Transaction_Date=@date, Account_Id=@accid WHERE TID=@tid", con)
            cmd.Parameters.AddWithValue("@tid", txtTID.Text)
            cmd.Parameters.AddWithValue("@type", txtTransactionType.Text)
            cmd.Parameters.AddWithValue("@amt", txtAmount.Text)
            cmd.Parameters.AddWithValue("@date", dtpTransactionDate.Value)
            cmd.Parameters.AddWithValue("@accid", txtAccountId.Text)

            con.Open()
            cmd.ExecuteNonQuery()
            con.Close()

            MessageBox.Show("Transaction updated successfully!")
            LoadTransactions()
        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message)
        Finally
            con.Close()
        End Try
    End Sub

    ' Delete transaction
    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        Try
            Dim cmd As New SqlCommand("DELETE FROM [transaction] WHERE TID=@tid", con)
            cmd.Parameters.AddWithValue("@tid", txtTID.Text)

            con.Open()
            cmd.ExecuteNonQuery()
            con.Close()

            MessageBox.Show("Transaction deleted successfully!")
            LoadTransactions()
        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message)
        Finally
            con.Close()
        End Try
    End Sub

    ' Load selected row into input fields
    Private Sub dgvTransaction_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgvTransaction.CellClick
        If e.RowIndex >= 0 Then
            Dim row As DataGridViewRow = dgvTransaction.Rows(e.RowIndex)
            txtTID.Text = row.Cells("TID").Value.ToString()
            txtTransactionType.Text = row.Cells("Transaction_Type").Value.ToString()
            txtAmount.Text = row.Cells("Amount").Value.ToString()
            dtpTransactionDate.Value = Convert.ToDateTime(row.Cells("Transaction_Date").Value)
            txtAccountId.Text = row.Cells("Account_Id").Value.ToString()
        End If
    End Sub
End Class
