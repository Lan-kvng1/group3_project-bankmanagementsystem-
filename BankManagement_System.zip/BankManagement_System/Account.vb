﻿Imports System.Data.SqlClient

Public Class Account

    Dim conn As New SqlConnection("Data Source=SECRET-GUEST;Initial Catalog=BankDB;Integrated Security=True")

    ' Load data into DataGridView
    Private Sub LoadAccountData()
        Try
            OpenConnection()
            Dim query As String = "SELECT * FROM accounts"
            Dim adapter As New SqlDataAdapter(query, conn)
            Dim table As New DataTable()
            adapter.Fill(table)
            dgv.DataSource = table
        Catch ex As Exception
            MsgBox("Error loading data: " & ex.Message)
        Finally
            CloseConnection()
        End Try
    End Sub

    Private Sub Account_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        dtp.Value = DateTime.Now
        LoadAccountData()
    End Sub

    Private Sub OpenConnection()
        If conn.State = ConnectionState.Closed Then
            conn.Open()
        End If
    End Sub

    Private Sub CloseConnection()
        If conn.State = ConnectionState.Open Then
            conn.Close()
        End If
    End Sub

    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        Try
            OpenConnection()
            Dim cmd As New SqlCommand("INSERT INTO accounts (Account_ID, Account_Type, Balance, Date_Opened, Customer_Name) VALUES (@id, @type, @bal, @date, @name)", conn)
            cmd.Parameters.AddWithValue("@id", txtAccountID.Text)
            cmd.Parameters.AddWithValue("@type", txtAccountType.Text)
            cmd.Parameters.AddWithValue("@bal", txtBalance.Text)
            cmd.Parameters.AddWithValue("@date", dtp.Value)
            cmd.Parameters.AddWithValue("@name", txtCustomerName.Text)
            cmd.ExecuteNonQuery()
            MsgBox("Account added successfully!")
            LoadAccountData() ' Refresh DataGridView
        Catch ex As Exception
            MsgBox("Error: " & ex.Message)
        Finally
            CloseConnection()
        End Try
    End Sub

    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        Try
            OpenConnection()
            Dim cmd As New SqlCommand("UPDATE accounts SET Account_Type=@type, Balance=@bal, Date_Opened=@date, Customer_Name=@name WHERE Account_ID=@id", conn)
            cmd.Parameters.AddWithValue("@id", txtAccountID.Text)
            cmd.Parameters.AddWithValue("@type", txtAccountType.Text)
            cmd.Parameters.AddWithValue("@bal", txtBalance.Text)
            cmd.Parameters.AddWithValue("@date", dtp.Value)
            cmd.Parameters.AddWithValue("@name", txtCustomerName.Text)
            cmd.ExecuteNonQuery()
            MsgBox("Account updated successfully!")
            LoadAccountData()
        Catch ex As Exception
            MsgBox("Error: " & ex.Message)
        Finally
            CloseConnection()
        End Try
    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        Try
            OpenConnection()
            Dim cmd As New SqlCommand("DELETE FROM accounts WHERE Account_ID=@id", conn)
            cmd.Parameters.AddWithValue("@id", txtAccountID.Text)
            cmd.ExecuteNonQuery()
            MsgBox("Account deleted successfully!")
            LoadAccountData()
        Catch ex As Exception
            MsgBox("Error: " & ex.Message)
        Finally
            CloseConnection()
        End Try
    End Sub

    ' ✅ Updated search to fill into DataGridView
    Private Sub btnSearch_Click(sender As Object, e As EventArgs) Handles btnSearch.Click
        Try
            OpenConnection()
            Dim cmd As New SqlCommand("SELECT * FROM accounts WHERE Account_ID LIKE @id OR Customer_Name LIKE @id", conn)
            cmd.Parameters.AddWithValue("@id", "%" & txtSearch.Text & "%")
            Dim adapter As New SqlDataAdapter(cmd)
            Dim table As New DataTable()
            adapter.Fill(table)
            dgv.DataSource = table

            If table.Rows.Count = 0 Then
                MsgBox("No matching records found.")
            End If
        Catch ex As Exception
            MsgBox("Error: " & ex.Message)
        Finally
            CloseConnection()
        End Try
    End Sub

    ' Load selected row into input fields
    Private Sub dgv_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgv.CellClick
        If e.RowIndex >= 0 Then
            Dim row = dgv.Rows(e.RowIndex)
            txtAccountID.Text = row.Cells("Account_ID").Value.ToString()
            txtAccountType.Text = row.Cells("Account_Type").Value.ToString()
            txtBalance.Text = row.Cells("Balance").Value.ToString()
            dtp.Value = Convert.ToDateTime(row.Cells("Date_Opened").Value)
            txtCustomerName.Text = row.Cells("Customer_Name").Value.ToString()
        End If
    End Sub

End Class
